function toggleSidebar(){
    document.getElementById("sidebar").classList.toggle("active");
}